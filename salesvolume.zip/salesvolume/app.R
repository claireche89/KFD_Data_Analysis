install.packages("shiny")
install.packages("tidyverse")
install.packages("lubridate")
install.packages("readxl")
library(shiny)
library(tidyverse)
library(lubridate)
library(scales)
library(readxl)

#This is the directory where you have downloaded and unzipped your file. 
setwd("D:/level/capstone/Kungfu Data")

#where you upload your csv file. 
kfd<-read_excel("salesvolume/data/salesvolumeshiny.xlsx")

 
# filter to only have sales 
sales <- kfd %>% 
  # select only the sales columns
  select(Month, Cereal_sales, Flour_sales, Premixed_powder) %>% 
  # this converts the data from wides to long, so we can plot it
  # each month - product pair will have a sales value
  gather(product, sales, -Month)  %>% 
  # change the data type and format of Month column
  mutate(Month = ymd(paste0(Month, "-01", sep = "")))


#To make the column values of product same with ui(Shiny) input category
sales$product[sales$product=="Cereal_sales"]<-"Cereal"
sales$product[sales$product=="Flour_sales"]<-"Flour"
sales$product[sales$product=="Premixed_powder"]<-"Premixed_powder"

#Let's do the same with volume
volume <- kfd %>% 
  select(Month, Cereal_volume, Flour_volume, Premixed_powder_volume) %>% 
  gather(product, volume, -Month)%>%  mutate(Month = ymd(paste0(Month, "-01", sep = "")))


volume$product[volume$product=="Cereal_volume"]<-"Cereal"
volume$product[volume$product=="Flour_volume"]<-"Flour"
volume$product[volume$product=="Premixed_powder_volume"]<-"Premixed_powder"


# Shiny ui 
ui<- fluidPage(
  titlePanel("Monthly sales and volume by product category"),
  
  sidebarLayout(
    sidebarPanel(
                         checkboxGroupInput("category1", 
                         label="product category to display", 
                       
                         choices = list( "Cereal", 
                                        "Flour", 
                                       "Premixed_powder"),
                         selected = "Cereal"),        
      
      
      
      
      
                         sliderInput("Daterange",
                              "Dates:",
                         min = as.Date("2016-05-01","%Y-%m-%d"),
                             max = as.Date("2019-01-01","%Y-%m-%d"),
                            value=c(as.Date("2016-05-01"), as.Date("2019-01-01")),
                            timeFormat=("%Y-%m")    
      
    
                     
    )),
    mainPanel(
      plotOutput("salesbycategory"),
      plotOutput("volumebycategory"),
      plotOutput("sales"),
      plotOutput("volume")
    )
  )
)


server <- function(input, output) {

  output$salesbycategory<-renderPlot({
    sales %>% 
       filter((Month >= as.Date(input$Daterange[1]))&(Month<=as.Date(input$Daterange[2]))) %>%
      filter(product %in% input$category1) %>%
      ggplot(aes(Month, sales, fill = product, group = product)) +
      geom_col(position = "dodge")+
      theme(axis.text.x = element_text(angle=90,hjust=1))+
     scale_x_date(date_breaks = "1 month", 
                 labels=date_format("%Y-%m"),
                 limits = as.Date(c('2016-05-01','2019-01-01')))+
      ggtitle("Monthly sales by category(dodge)")+xlab("Date")+ylab("sales(yuan)")
    
  })

  output$volumebycategory<-renderPlot({
   volume %>% 
      filter((Month >= as.Date(input$Daterange[1]))&(Month<=as.Date(input$Daterange[2]))) %>%
      filter(product %in% input$category1) %>%
      ggplot(aes(Month, volume, fill = product, group = product)) +
      geom_col(position = "dodge")+
      theme(axis.text.x = element_text(angle=90,hjust=1))+
      scale_x_date(date_breaks = "1 month", 
                   labels=date_format("%Y-%m"),
                   limits = as.Date(c('2016-05-01','2019-01-01')))+
      ggtitle("Monthly volume by category(dodge)")+xlab("Date")+ylab("volume")
    
  })
  
   output$sales<-renderPlot({
    sales %>% 
     filter(Month >= as.Date(input$Daterange[1])&Month<=as.Date(input$Daterange[2])) %>%
       filter(product %in% input$category1) %>%
      ggplot(aes(Month, sales, fill = product, group = product)) +
     geom_col()+
      theme(axis.text.x = element_text(angle=90,hjust=1)) +
      scale_x_date(date_breaks = "1 month", 
                labels=date_format("%Y-%m"),
                limits = as.Date(c('2016-05-01','2019-01-01')))+
   ggtitle("Monthly sales by category(stacked)")+xlab("Date")+ylab("sales(yuan)")
    
  })
   
 output$volume<-renderPlot({
   volume %>% 
     filter(Month >= as.Date(input$Daterange[1])&Month<=as.Date(input$Daterange[2])) %>%
     filter(product %in% input$category1) %>%
     ggplot(aes(Month, volume, fill = product, group = product)) +
     geom_col()+
     theme(axis.text.x = element_text(angle=90,hjust=1)) +
     scale_x_date(date_breaks = "1 month", 
                  labels=date_format("%Y-%m"),
                  limits = as.Date(c('2016-05-01','2019-01-01')))+
    ggtitle("Monthly sales by volume(stacked)")+xlab("Date")+ylab("volume")
   
 })
 }
  
shinyApp(ui = ui, server = server)







