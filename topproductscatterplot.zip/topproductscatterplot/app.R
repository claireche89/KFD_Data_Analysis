#You don't need to install shiny package again if you have installed it in your Rstudio
install.packages("shiny")
library(shiny)
library(tidyverse)
library(readxl)
# this cleans model output from our lm
library(broom) 


# This is the directory of the folder where you have downloaded and unzipped your file. 
setwd("D:/level/capstone/Kungfu Data")

# This is where you load your data. 
a<-read_excel("topproductscatterplot/data/KFD xxx top product.xlsx")


#Only keep the rows with Sales>=0
c<-a[a$Sales_RMB_30_Days>0,]
#remove NA values
c<-c[complete.cases(c),]


#Check if the variables are skewed. if skewed, normalize the variables.
#Sales_RMB_30_Days
hist(c$Sales_RMB_30_Days)
c$Log_Sales_30Days<-log10(c$Sales_RMB_30_Days)
hist(c$Log_Sales_30Days)

#Units_30_Days
hist(c$Units_30_Days)
c$Log_Units_30Days<-log10(c$Units_30_Days)
hist(c$Log_Units_30Days)

#unit price
c$avg_unit_price<-(c$Lowest_Price_RMB+c$Highest_Price_RMB)/2
hist(c$avg_unit_price)
c$Log_avg_unit_price<-log10(c$avg_unit_price)


#lifetime_Sales
hist(c$Lifetime_Sales_RMB)
c$log_lifetime_sales<-log(c$Lifetime_Sales_RMB)
hist(c$log_lifetime_sales)


#lifetime_units
hist(c$Lifetime_Units)
c$log_lifetime_units<-log(c$Lifetime_Units)
hist(c$log_lifetime_units)

#reviews
hist(c$Reviews)
c$log_reviews<-log(c$Reviews)
hist(c$log_reviews)

#Select the continuous variables to plot in the scatterplots 
c<-c%>% select(Sales_RMB_30_Days,Units_30_Days,Log_avg_unit_price,Log_Sales_30Days,Log_Units_30Days,log_lifetime_sales,log_lifetime_units,Months_Open,Reviews,log_reviews,Store_Level)
#remove the infinite values 
c <- c[!is.infinite(rowSums(c)),]



ui<- fluidPage(
  titlePanel("scatterplots"),
  
  sidebarLayout(
    sidebarPanel(
     selectInput("column1", 
                         label="var1", 
                         choices = list( "Sales_RMB_30_Days" ,
                                          "Log_Sales_30Days" ,
                                         "Units_30_Days",
                                         "Log_Units_30Days" ,
                                         "avg_unit_price" ,
                                         "Log_avg_unit_price" ,
                                         "Lifetime_Sales_RMB",
                                         "log_lifetime_sales",
                                         "Lifetime_Units" ,
                                         "log_lifetime_units" ,
                                         "Reviews" ,
                                         "log_reviews" ,
                                         
                                         "Months_Open",
                                         "Store_Level"),
                         selected = "Log_Sales_30Days"),        
      
     selectInput("column2", 
                 label="var2", 
                 choices = list( "Sales_RMB_30_Days" ,
                                 "Log_Sales_30Days" ,
                                 "Units_30_Days",
                                 "Log_Units_30Days" ,
                                 "avg_unit_price" ,
                                 "Log_avg_unit_price" ,
                                 "Lifetime_Sales_RMB",
                                 "log_lifetime_sales",
                                 "Lifetime_Units" ,
                                 "log_lifetime_units" ,
                                 "Reviews" ,
                                 "log_reviews" ,
                                 "Months_Open",
                                 "Store_Level"),
                 selected = "Log_Units_30Days")    
      
      
      
      
      ),
   mainPanel(
      plotOutput("scatterplot"),
      dataTableOutput("lmSum")
    )
  )
)


server <- function(input, output) {
  
  
  my_df <- reactive({
    select(c, x = !!input$column1, y = !!input$column2)
  })
 
 
  output$scatterplot<-renderPlot({

    my_gg<-ggplot(data = my_df(), aes(x, y)) +
    geom_point()+
      geom_smooth(method="lm") +
      labs(x = input$column1, y = input$column2)
    
    my_gg
    
   
    
  })
  
  output$lmSum <- renderDataTable({
  
  
  tidy(lm(y ~ x, data = my_df(),na.action=na.omit))
    })
  
}

shinyApp(ui = ui, server = server)


