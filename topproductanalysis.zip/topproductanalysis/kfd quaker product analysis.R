# If you have these packages in your R studio, there is no need to install them again.
install.packages("readxl")
install.packages("tidyverse")
install.packages("moments")
install.packages("corrplot")
library(readxl)
library(tidyverse)
library(moments)
library(corrplot)

# read excel file into R 
a<-read_excel("D:/level/capstone/Kungfu Data/topproductanalysis/Quaker top product.xlsx")

# check the encoding of product title which contains chinese character
Encoding(a$Product_Title)

# check if product title shows correctly
a$Product_Title

#remove the rows with Sales_RMB_30_Days<=0
c<-a[a$Sales_RMB_30_Days>0,]
#remove the NA values
c<-c[complete.cases(c),]

#Check if the distributions of the variables are skewed. if skewed, transform them.
#Sales_RMB_30_Days
hist(c$Sales_RMB_30_Days)
c$Log_Sales_30Days<-log10(c$Sales_RMB_30_Days)
hist(c$Log_Sales_30Days)

#Units_30_Days
hist(c$Units_30_Days)
c$Log_Units_30Days<-log10(c$Units_30_Days)
hist(c$Log_Units_30Days)

#unit price
c$avg_unit_price<-(c$Lowest_Price_RMB+c$Highest_Price_RMB)/2
hist(c$avg_unit_price)
c$Log_avg_unit_price<-log10(c$avg_unit_price)
hist(c$Log_avg_unit_price)

#lifetime_Sales
hist(c$Lifetime_Sales_RMB)
c$log_lifetime_sales<-log(c$Lifetime_Sales_RMB)
hist(c$log_lifetime_sales)

#lifetime_units
hist(c$Lifetime_Units)
c$log_lifetime_units<-log(c$Lifetime_Units)
hist(c$log_lifetime_units)

#reviews
hist(c$Reviews)
c$log_reviews<-log(c$Reviews)
hist(c$log_reviews)

#Trending% 30days/lifetime
hist(c$`Trending_%30Day/Lifetime`)
c$'log_trending%30days/lifetime'<-log(c$`Trending_%30Day/Lifetime`)
hist(c$`log_trending%30days/lifetime`)
c$'log2_trending%30days/lifetime'<-log2(c$`Trending_%30Day/Lifetime`)
hist(c$`log2_trending%30days/lifetime`)
#log2_trending%30days/lifetime is more normally distributed.

#Monthsopen
hist(c$Months_Open)

#storelevel
hist(c$Store_Level)

#store_favourable_rate
hist(c$Store_Favorable_Rate)
#not much variation

#store location
table(c$Store_Location)


#reviews by category
hist(c$Description)
hist(c$Cust_Service)
hist(c$Shipping)
#not much variation 


# plot product sales for first tier category
# scatterplot
c%>% ggplot(aes(x=Log_Sales_30Days, y=log_lifetime_sales, color=First_Tier_Category))+
  geom_point()+
  theme_minimal()+
  labs(title="plot of products sold by first tier category", x="log_sales_30days", y="log_lifetime_sales")
#barplot  
c%>% count(First_Tier_Category)%>%
ggplot(aes(x= First_Tier_Category, y=n))+
  geom_bar(stat="identity", fill="red")+
  theme_minimal()+
  geom_text(aes(label=n), vjust=1.6, color="white", size=3.5)+
  labs(title="Plot of number of products by first tier category", x="first tier category", y="number of products")+
  theme(axis.text.x = element_text(angle = 50, hjust = 1))


#plot product sales for store type
#boxplot
c$Store_Type<-as.factor(c$Store_Type)
c%>% ggplot(aes(x=Store_Type, y=Log_Sales_30Days))+
  geom_boxplot()+
  theme_minimal()+
  labs(title="Plot of products sold by store type", x="store type", y="log_sales_30days")
#barplot
c%>% count(Store_Type)%>%
  ggplot(aes(x= Store_Type, y=n))+
  geom_bar(stat="identity", fill="red")+
  theme_minimal()+
  geom_text(aes(label=n), vjust=1.6, color="white", size=3.5)+
  labs(title="Plot of number of products by store type", x="store type", y="number of products")


#plot product sales for store location
#barplot
c%>% count(Store_Location)%>%
  ggplot(aes(x= Store_Location, y=n))+
  geom_bar(stat="identity", fill="red")+
  theme_minimal()+
  geom_text(aes(label=n), vjust=1.6, color="white", size=3.5)+
  labs(title="Plot of products sold by store location", x="store location", y="number of products")+
  theme(axis.text.x = element_text(angle = 50, hjust = 1))

#select the top 5 locations by number of products and plot a boxplot afterwards
e<-c%>%count(Store_Location)%>%top_n(5)
e$Store_Location<-as.factor(e$Store_Location)
c%>% filter(Store_Location==e$Store_Location)%>%
            ggplot(aes(x=Store_Location, y=Log_Sales_30Days))+
  geom_boxplot()+
  theme_minimal()+
  labs(title="Plot of products sold by store location", x="store location", y="log_sales_30days")+
  theme(axis.text.x = element_text(angle = 50, hjust = 1))


# select the numeric variables and prepare them for linear regression 
i<-c%>% select(Sales_RMB_30_Days,Units_30_Days,Log_avg_unit_price,Log_Sales_30Days,Log_Units_30Days,log_lifetime_sales,log_lifetime_units,`Trending_%30Day/Lifetime`,`log2_trending%30days/lifetime`,Months_Open,Reviews,log_reviews,Store_Level)
i <- i[!is.infinite(rowSums(i)),]
i
str(i)

# linear regression Log_Sales_30Days vs. log_reviews
n<-lm(i$Log_Sales_30Days~i$log_reviews)
cor(i$Log_Sales_30Days,i$log_reviews)
summary(n)
plot(n)

# linear regression Log_Sales_30Days vs. Store_Level
f<-lm(i$Log_Sales_30Days~i$Store_Level)
cor(i$Log_Sales_30Days,i$Store_Level)
summary(f)
plot(f)

# multilinear regression log_sales_30Days vs. log_reviews+Store_level
g<-lm(i$Log_Sales_30Days~i$log_reviews+i$Store_Level)
summary(g)
plot(g)

# select the continuous variables that you would like to include in the correlation plot 
k<- i%>% select(Log_avg_unit_price,Log_Sales_30Days,Log_Units_30Days,log_lifetime_sales,Log_Units_30Days,Months_Open,log_reviews,Store_Level)
l<-cor(k)
corrplot(l, type="upper", tl.col="black", tl.srt=45)
