#https://cran.r-project.org/web/packages/corpus/vignettes/chinese.html

install.packages("httr")
install.packages("stringi")
install.packages("wordcloud")
install.packages("corpus")
install.packages("RColorBrewer")
install.packages("extrafont")
install.packages("showtext")
library("httr")
library("stringi")
library("wordcloud")
library("corpus")
library("tidyverse")

#setting a seed to ensure reproducible results
set.seed(100)

#Documents and stopwords
#First download a stop word list suitable for Chinese, the Baidu stop words
cstops <- "https://raw.githubusercontent.com/ropensci/textworkshop17/master/demos/chineseDemo/ChineseStopWords.txt"
csw <- paste(readLines(cstops, encoding = "UTF-8"), collapse = "\n") # download
csw <- gsub("\\s", "", csw)           # remove whitespace
stop_words <- strsplit(csw, ",")[[1]] # extract the comma-separated words
#Next, download some demonstration documents. These are in plain text format, encoded in UTF-8.


library(readxl)
#This is the directory where you download and unzip your file.
setwd("D:/level/capstone/Kungfu Data")
# This is where you would load your excel file. 
a<-read_excel("textmining/KFD xxx top product.xlsx")

# filter the data whith sales_30_days>0
b<-a %>% filter(Sales_RMB_30_Days>0)
# select which column you are interested in looking at
text<-b$Product_Title


#We use stringi’s tokenizer, collect a dictionary of the word types, and then manually insert zero-width spaces between tokens.
toks <- stringi::stri_split_boundaries(text, type = "word")
dict <- unique(c(toks, recursive = TRUE)) # unique words
text2 <- sapply(toks, paste, collapse = "\u200b")
data <- corpus_frame( text = text2)
f <- text_filter(drop_punct = TRUE, drop = stop_words, combine = dict)
(text_filter(data) <- f)
text_stats(data)
c<-(stats <- term_stats(data))
c
font_family <- par("family") # the previous font family
par(family = "STSong") # change to a nice Chinese font
with(stats, {
  wordcloud::wordcloud(term, count, min.freq = 50,
                       random.order = FALSE, rot.per = 0.25,
                       colors = RColorBrewer::brewer.pal(8, "Dark2"))
})
